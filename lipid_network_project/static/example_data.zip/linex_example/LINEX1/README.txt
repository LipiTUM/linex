# Data Files

Lipid_data_file.csv contains quantitative lipidomics data.
Sample_groups.csv contains information on sample age (i.e. metadata).
Lipid_class_settings.txt contains customised lipid class settings.


# Usage in LINEX

## File Upload
1. upload Lipid_data_file.csv at 'Required Input Data'
2. upload Sample_groups.csv at 'Optional Samlple Data'
3. upload Lipid_class_settings.txt at the upper field under 'Optional Model Settings'

## Settings
* select 'Data is log-transformed'

Select 'Upload & Compute Network'

NOTE: In order to see updates on the progress page, please use the refresh button

# Download
In order to provide files to collaborators or for review/publication you can download a standalone .html on the 'Download' page, which can then be opened in any browser (without connection to the actual server).

# Information on data
log-transformed data from the reference population described/published in Kyle et al. 2015, Nature Scientifc Data (https://doi.org/10.1038/s41597-021-00894-y).

