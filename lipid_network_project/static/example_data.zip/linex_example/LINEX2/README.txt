# Information on data
log-transformed data from the reference population described/published in Kyle et al. 2015, Nature Scientifc Data (https://doi.org/10.1038/s41597-021-00894-y).

